﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CsvHelper;

namespace GelatiManager
{
    public class Gelato
    {
        public int IdGelato { get; set; }
        public string Nome { get; set; }
        public string Descrizione { get; set; }
        public decimal Prezzo { get; set; }
        public List<Ingredienti> Ingredienti { get; set; }
    }

    public class Ingredienti
    {
        public int IdGelato { get; set; }
        public int Tipo { get; set; }
        public string Valore { get; set; }
        public string Calorie { get; set; }
        public string Colorante { get; set; }
        public string Lattosio { get; set; }

    }

    public class Program
    {
        public static void Main(string[] args)
        {
            string gelatiPath = "Gelati.csv";
            string ingredientiPath = "ingredienti.csv";

            var gelati = CaricaGelatiDaFile(gelatiPath);
            AggiungiIngredientiAGelati(gelati, ingredientiPath);
            foreach (var gelato in gelati)
            {
                Console.WriteLine($"Gelato: {gelato.Nome}, Prezzo: {gelato.Prezzo}");
                Console.WriteLine($"Descrizione: {gelato.Descrizione}");

                foreach (var ingrediente in gelato.Ingredienti)
                {
                    Console.WriteLine($"- {ingrediente.Valore}, Calorie: {ingrediente.Calorie}, Colorante: {ingrediente.Colorante}, Lattosio: {ingrediente.Lattosio}");
                }

                Console.WriteLine();
            }
        }

        private static List<Gelato> CaricaGelatiDaFile(string path)
        {
            List<Gelato> gelati = new List<Gelato>();

            using (var reader = new StreamReader(path))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                gelati = csv.GetRecords<Gelato>().ToList();
            }

            return gelati;
        }

        private static void AggiungiIngredientiAGelati(List<Gelato> gelati, string path)
        {
            using (var reader = new StreamReader(path))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var ingredienti = csv.GetRecords<Ingredienti>().ToList();

                foreach (var gelato in gelati)
                {
                    gelato.Ingredienti = ingredienti.FindAll(i => i.IdGelato == gelato.IdGelato);
                }
            }
        }
    }
}
