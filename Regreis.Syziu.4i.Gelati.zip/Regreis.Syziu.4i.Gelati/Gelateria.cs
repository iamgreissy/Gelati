﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Formats.Asn1;
using System.IO;
using System.Linq;
using CsvHelper;
using System.Windows;

namespace Regreis.Syziu._41.Gelati
{
    public enum Ingrediente
    {
        Panna,
        Colorante,
        Aroma,
        PannaDiSoia,
        Cacao,
        Latte,
        Caffè,
        Mascarpone,
        Uovo
    }

    public class Ingredienti
    {
        public int IdGelato { get; set; }
        public Ingrediente Tipo { get; set; }
        public string Descrizione { get; set; }
        public string Valore { get; set; }
    }

    public class Gelato
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Descrizione { get; set; }
        public decimal Prezzo { get; set; }
        public List<Ingredienti> Ingredienti { get; set; }
    }

    public class Gelati
    {
        public List<Gelato> ListaGelati { get; set; }

        public Gelati()
        {
            ListaGelati = new List<Gelato>();
        }
    }
}