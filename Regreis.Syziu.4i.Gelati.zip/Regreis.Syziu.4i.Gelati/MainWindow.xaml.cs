﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows;
using CsvHelper;
using Regreis.Syziu._41.Gelati;

namespace WpfApp
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private Gelati gelati;
        public Gelati Gelati
        {
            get { return gelati; }
            set
            {
                gelati = value;
                OnPropertyChanged("Gelati");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            CaricaDati();
        }

        private void CaricaDati()
        {
            Gelati = CaricaGelatiDaFile("Gelati.csv");
            AggiungiIngredientiAGelati("Ingredienti.csv");
        }

        private Gelati CaricaGelatiDaFile(string path)
        {
            Gelati gelati = new Gelati();
            try
            {
                using (var reader = new StreamReader(path))
                using (var csv = new CsvReader(reader, System.Globalization.CultureInfo.InvariantCulture))
                {
                    var records = csv.GetRecords<Gelato>().ToList();
                    gelati.ListaGelati = records;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante il caricamento dei gelati: " + ex.Message);
            }
            return gelati;
        }

        private void AggiungiIngredientiAGelati(string path)
        {
            try
            {
                using (var reader = new StreamReader(path))
                using (var csv = new CsvReader(reader, System.Globalization.CultureInfo.InvariantCulture))
                {
                    var records = csv.GetRecords<Ingredienti>().ToList();
                    foreach (var gelato in Gelati.ListaGelati)
                    {
                        gelato.Ingredienti = records
                            .Where(i => i.IdGelato == gelato.Id)
                            .Select(i =>
                            {
                                switch (i.Tipo)
                                {
                                    case Ingrediente.Panna:
                                        i.Valore += ", Calorie: " + i.Valore;
                                        break;
                                    case Ingrediente.Colorante:
                                        i.Valore = "Colorante: " + i.Valore;
                                        break;
                                    case Ingrediente.Latte:
                                        i.Valore = "Lattosio: " + i.Valore;
                                        break;
                                }
                                return i;
                            })
                            .ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante il caricamento degli ingredienti: " + ex.Message);
            }
        }
    }
}