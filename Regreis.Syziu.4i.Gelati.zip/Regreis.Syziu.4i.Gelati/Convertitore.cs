﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;
using CsvHelper;
using Regreis.Syziu._41.Gelati;

namespace Convertitore
{
    public class IngredientiConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is List<Ingredienti> ingredienti)
            {
                StringBuilder sb = new StringBuilder();
                foreach (var ingrediente in ingredienti)
                {
                    sb.AppendLine($"Tipo: {ingrediente.Tipo}, Descrizione: {ingrediente.Descrizione}, Valore: {ingrediente.Valore}");
                }
                return sb.ToString();
            }

            return string.Empty;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
